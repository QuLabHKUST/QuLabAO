% This is the imageJ code to process raw data from scanimage

% There are 3 configurable variable in this code: IsStackReg, nch and processch
% IsStackReg = 0 -> no stack registration is applied; IsStackReg = 1 -> stack registration is applied
% nch = 2 -> raw data is two channel image stack; nch = 1 -> raw data is one channel image stack
% processch = 1 -> only process channel 1; processch = 2 -> process both channels

% How to use?

% run this code in imageJ and input root folder to be processed in the dialog box.
% the processed image will be saved in corresponding subfolder